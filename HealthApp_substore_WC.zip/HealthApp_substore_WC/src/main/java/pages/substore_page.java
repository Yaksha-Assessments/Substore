package pages;

import java.util.Map;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class substore_page extends StartupPage {

	public substore_page(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public By getUsernameTextfieldLocator() {
		return By.id("username_id");
	}

	public By getPasswordTextboxLocator() {

		return By.xpath("//input[@id='password']");
	}

	public By getSignInButtonLocator() {
		return By.xpath("//button[@id='login']");
	}

	public By getDropDownLocater() {
		return By.xpath("//a[@href='#/WardSupply']");
	}

	public By getRadiologyLocator() {
		return By.xpath("//a[@href='#/Radiology']");
	}

	public By getDropDownInventoryLocater() {
		return By.xpath("//a[@href='#/Inventory']");
	}

	public By getAccountsButton() {
		return By.xpath("//body//my-app//div[@class='row']//div[@class='row']//div[1]//a[1]//div[1]");
	}

	public By getAnchorTagLocatorByText(String anchorTagName) {
		return By.xpath("//a[contains(text(),'" + anchorTagName + "')]");
	}

	public By getPageBarFixedLocator(String navBarName) {
		if (navBarName.equalsIgnoreCase("Accounts")) {
			navBarName = "ImagingRequisitionList";
		} else if (navBarName.equalsIgnoreCase("male ward SubStore")) {
			navBarName = "ImagingReportsList";
		} else if (navBarName.equalsIgnoreCase("SubStore1")) {
			navBarName = "EditDoctors";
		} else if (navBarName.equalsIgnoreCase("Substore3")) {
		}
		return By.xpath("//ul[@class='page-breadcrumb']/li/a[@href='#/Substore/" + navBarName + "']");
	}

	public By getSubstoreBoxOptionLocatorByText(String optionToSelect) throws Exception {
		return By.xpath("//ul[@id='SubStore']//span[contains(text(),'" + optionToSelect + "')]");
	}

	public By getSubstoreBoxLocator() {
		return By.xpath("//ul[@id='SubStore']");
	}

	public By getSubstoreSubmodulesLocator() {
		return By.xpath("//ul[@class='nav nav-tabs']");
	}

	public By getCounters() {
		return By.xpath("//a[@class='report_list']");
	}

	public By getCreateRequisitionButton() {
		return By.xpath("//button/span[text()='Create Requisition']");
	}

	public By searchBarId() {
		return By.id("quickFilterInput");
	}

	public By getStarIconLocator() {
		return By.xpath("//i[contains(@class,'icon-favourite')]/..");
	}

	public By getRadioButtonLocator(String radioButtonName) {
		return By.xpath("//label[contains(text(),'" + radioButtonName + "')]/span");
	}

	public By getTargetInventory() {
		return By.xpath("//input[@id='activeInventory']");
	}

	public By getItemName() {
		return By.xpath("//input[@id='itemName0']");
	}

	public By getRequiredQuantity() {
		return By.xpath("//input[@id='qtyip0']");
	}

	public By getRequestButton() {
		return By.cssSelector("input#save_requisition");
	}

	public By favouriteOrStarIcon() {
		return By.xpath("//i[contains(@class,'icon-favourite')]");
	}

	public By getCloseRequest() {
		return By.xpath("//i[@class='fa fa-close']");
	}

	public By getCloseModalLocator() {
		return By.cssSelector("a[title='Cancel']");
	}

	public By getDateRangeButton() {
		return By.xpath("//span[@class='icon-range-ddl dropdown-toggle']");
	}

	public By getOneWeekButton() {
		return By.xpath("//a[normalize-space()='Last 1 Week']");
	}

	public By getViewButton() {
		return By.xpath(
				"//div[@class='ag-cell ag-cell-not-inline-editing ag-cell-with-height ag-cell-value ag-cell-focus ag-column-hover']//a[@class='grid-action'][normalize-space()='View']");
	}

	public By getCloseViewItem() {
		return By.xpath("//a[@class='btn btn-danger history-del-btn']");
	}

	public By getInternalCloseviewItem() {
		return By.xpath("//a[@class='btn btn-danger history-del-btn']");
	}

	public By getDirectDispatchButton() {
		return By.xpath("//button[contains(text(),'Direct') and contains(text(),'Dispatch')]");
	}

	public By getBackToReqListButton() {
		return By.xpath("//button[contains(text(),'Back') and contains(text(),'to')]");
	}

	public By getRequestedToColumn() {
		return By.cssSelector("div[col-id=\"StoreName\"]");
	}

	public By getStatusColumnLocator() {
		return By.cssSelector("div[col-id='RequisitionStatus']");
	}

	public By getStoreName() {
		return By.cssSelector("input#store");
	}

	public By getInternalItemNameButton() {
		return By.cssSelector("input#itemName0");
	}

	public By getDispatchedQuantityButton() {
		return By.xpath("//input[@id='qtyip0']");
	}

	public By getRemarksButton() {
		return By.xpath("//textarea[@id='remarks']");
	}

	public By getInternalDirectDispatchButton() {
		return By.cssSelector("input#directDispatchButton");
	}

	public By getRecieveItemsButton() {
		return By.xpath("//a[@class='grid-action animated-btn blinking-btn-warning grid-action']");
	}

	public By getRecieveButton() {
		return By.xpath("//button[@id='ReceiveButton']");
	}

	public By getNewConsumptionButton() {
		return By.xpath("//a[(@class='btn btn-primary btn-sm m1')]");
	}

	public By getConsumptionDate() {
		return By.xpath("//input[@id='date']");
	}

	public By getSubModuleLocator() {
		return By.xpath("//ul[contains(@class,'nav-tabs')]//li//a");
	}

	public By calendarFromDropdown() {
		return By.xpath("(//input[@id='date'])[1]");
	}

	public By calendarToDropdown() {
		return By.xpath("(//input[@id='date'])[2]");
	}

	public By getAllRequisitionDate() {
		return By.xpath("//div[@col-id='RequisitionDate' and @role='gridcell']");
	}

	public By getGeneralInventory() {
		return By.cssSelector("select#selectedInventory");
	}

	public By getDotDropDownButton() {
		return By.xpath("(//button[@class='dropdown-toggle grid-btnCstm'])[1]");
	}

	public By getCounterReportModuleButton() {
		return By.xpath("(//a[@class='report_list'])[3]");
	}

	public By getShowReportButton() {
		return By.xpath("//button[@class='btn blue']");
	}

	public By getReturnItemsButton() {
		return By.xpath("//input[@type='button']");
	}

	public By getSelectInventoryButton() {
		return By.xpath("//select[@id='selectInventory']");
	}

	public By getGeneralInventoryButton() {
		return By.xpath("//option[@value='2']");
	}

	public By getReturnQtyButton() {
		return By.cssSelector("input[name=\"returnQty\"]");
	}

	public By getReturnButton() {
		return By.xpath("//button[@id='save']");
	}

	public By getCounterButtonFourth() {
		return By.xpath("//a[@class='report_list']");
	}

	public By getButtonLocatorsBytext(String buttonName) {
		return By.xpath("//button[contains(text(),'" + buttonName + "')]");
	}

	public By getPopUpMessageText(String msgStatus, String messageText) {
		return By.xpath("//p[contains(text(),' " + msgStatus + " ')]/../p[contains(text(),'" + messageText + "')]");
	}

	public By popupCloseButton() {
		return By.cssSelector("a.close-btn");
	}

	public By printModalLocator() {
		return By.cssSelector("div#printpage");
	}

	public By getEllipsisButtonByStatus(String status) {
		return By.xpath("//div[text()='" + status + "']/../div/span/div/button[contains(text(),'...')]");
	}

	public By getReceiveButtonByStatus(String status) {
		return By.xpath("//div[text()='" + status + "']/../div/span/a[@title='Receive Dispatched Items']");
	}

	public By getStockAvailableQuantity(String categoryName) {
		return By.xpath("//div[@col-id='SubCategoryName' and contains(text(),'" + categoryName
				+ "')]/../div[@col-id='AvailableQuantity']/span/div");
	}

	public By getSaveButtonLocator() {
		return By.cssSelector("input#save");
	}

	public By getReportsTableLocator() {
		return By.cssSelector("div[ref=\"eCenterContainer\"]  div[role='row']");
	}

	public By getModuleSignoutLocator() {
		return By.xpath("//i[contains(@class,'sign-out')]");
	}

	public By getHoverText() {
		return By.xpath("//h6[contains(text(),'To change, you can always click here.')]");
	}

	/**
	 * @Test1.1 about this method loginTohealthAppByGivenValidCredetial()
	 * 
	 * @param : Map<String, String>
	 * @description : fill usernameTextbox & passwordTextbox and click on sign in
	 *              button
	 * @return : Boolean
	 * @author : Yaksha
	 */
	public boolean loginToHealthAppByGivenValidCredetial(Map<String, String> expectedData) throws Exception {
		Boolean textIsDisplayed = false;
		try {
			WebElement usernametextFieldWebElement = commonEvents.findElement(getUsernameTextfieldLocator());
			commonEvents.highlightElement(usernametextFieldWebElement);
			commonEvents.sendKeys(getUsernameTextfieldLocator(), expectedData.get("username"));

			WebElement passwordtextFieldWebElement = commonEvents.findElement(getPasswordTextboxLocator());
			commonEvents.highlightElement(passwordtextFieldWebElement);
			commonEvents.sendKeys(getPasswordTextboxLocator(), expectedData.get("password"));

			WebElement signinButtonWebElement = commonEvents.findElement(getPasswordTextboxLocator());
			commonEvents.highlightElement(signinButtonWebElement);
			commonEvents.click(getSignInButtonLocator());
			textIsDisplayed = true;
		} catch (Exception e) {
			throw e;
		}
		return textIsDisplayed;

	}

	/**
	 * @Test1.2 @Test17.2 @Test18.2 @Test19.1 about this method
	 * scrollDownAndClickMaternityTab()
	 * 
	 * @param : null
	 * @description : verify the Substore tab, scroll to it, and click it
	 * @return : String
	 * @author : YAKSHA
	 */
	public boolean scrollDownAndClickSubstoreTab() throws Exception {
		boolean scrolledTillElement = false;
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			WebElement SubstoreTab = commonEvents.findElement(getDropDownLocater());
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", SubstoreTab);
			jsExecutor.executeScript("window.scrollBy(0, -50)");
			commonEvents.highlight(SubstoreTab);
			commonEvents.click(SubstoreTab);

			// Wait for the URL to contain "WardSupply"
			commonEvents.waitForUrlContains("WardSupply", 30);

			scrolledTillElement = true;
		} catch (Exception e) {
			throw e;
		}
		return scrolledTillElement;
	}

	/**
	 * @Test1.3 about this method verifyVerificationPageUrl()
	 * 
	 * @param : null
	 * @description : verify verification page url
	 * @return : String
	 * @author : YAKSHA
	 */

	public String verifySubstorePageUrl() throws Exception {
		try {
			String titleToVerify = commonEvents.getCurrentUrl();
			return titleToVerify;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test2 about this method clickFirstCounterIfAvailable
	 * 
	 * @param : null
	 * @description : Clicks Counter modules
	 * @return : Boolean
	 * @throws : YAKSHA
	 */
	public boolean clickFourthCounterIfAvailable() throws Exception {
		try {
			List<WebElement> counterElements = commonEvents.getWebElements(getCounterButtonFourth());
			System.out.println("Elemets size >> " + counterElements.size());
			int numberOfCounterElements = counterElements.size();
			if (numberOfCounterElements > 0) {
				commonEvents.highlight(counterElements.get(0)).click(counterElements.get(0));
			}
			return true;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test3 about this method verifyModuleSignoutHoverText()
	 * @param substoreExpectedData : Map<String, String> - Contains expected hover
	 *                             text
	 * @description : This method verifies that the hover text on the "Sign Out"
	 *              module matches the expected value.
	 * @return : boolean - true if the hover text matches the expected value, false
	 *         otherwise.
	 * @throws : Exception - if there is an issue finding the hover text or any
	 *           other operation.
	 * @author : YAKSHA
	 */
	public boolean verifyModuleSignoutHoverText(Map<String, String> substoreExpectedData) throws Exception {
		try {
			// Click on the "Inventory" section.
			commonEvents.click(getAnchorTagLocatorByText("Inventory"));

			// Locate the "Sign Out" module for hover action.
			WebElement elementToHover = commonEvents.findElement(getModuleSignoutLocator());

			// Create an instance of Actions class to perform hover action.
			Actions actions = new Actions(driver);

			// Perform the hover action on the "Sign Out" module.
			actions.moveToElement(elementToHover).perform();

			// Retrieve the hover text displayed.
			String elementText = commonEvents.findElement(getHoverText()).getText();
			System.out.println("Element text -->  " + elementText);

			// Check if the hover text matches the expected value.
			if (elementText.contains(substoreExpectedData.get("moduleSignOutHoverText"))) {
				return true;
			} else {
				throw new Exception("Hover text did not match the expected value.");
			}

		} catch (Exception e) {
			// Throw a meaningful exception indicating what failed.
			throw new Exception("Failed to verify the hover text on the 'Sign Out' module: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test4 about this method verifySubstoreSubModule()
	 * @param substoreExpectedData : Map<String, String> - A map containing expected
	 *                             substore data, such as URLs or other related
	 *                             information.
	 * @description : This method verifies that the substore module's sub-modules
	 *              (e.g., Inventory, Pharmacy) are visible and interactable.
	 * @return : boolean - true if the sub-modules are visible and clickable, false
	 *         otherwise.
	 * @throws : Exception - if there is an issue finding or interacting with the
	 *           sub-modules.
	 * @author : YAKSHA
	 */
	public boolean verifySubstoreSubModule(Map<String, String> substoreExpectedData) throws Exception {
		try {
			System.out.println("Substore Page URL: " + substoreExpectedData.get("URL"));

			// Find the Inventory and Pharmacy sub-modules
			WebElement inventorySubModule = commonEvents.findElement(getAnchorTagLocatorByText("Inventory"));
			WebElement pharmacySubModule = commonEvents.findElement(getAnchorTagLocatorByText("Pharmacy"));

			// Highlight and click on the Inventory sub-module
			commonEvents.highlight(inventorySubModule).click(inventorySubModule);

			// Highlight and click on the Pharmacy sub-module
			commonEvents.highlight(pharmacySubModule).click(pharmacySubModule);

			return true;
		} catch (Exception e) {
			throw new Exception("Failed to verify substore sub-modules due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test5 about this method subModulePresent()
	 * 
	 * @param moduleName : String - The name of the module to verify.
	 * @description : This method verifies if the specified module's sub-modules are
	 *              present and visible.
	 * @return : boolean - true if the sub-modules are displayed, false otherwise.
	 * @throws : Exception - if there is an issue finding the sub-modules or if no
	 *           elements are found.
	 * @author : YAKSHA
	 */
	public boolean subModulePresent(String moduleName) throws Exception {
		boolean areModulesDisplayed = false;
		try {
			// Click on the specified module
			commonEvents.click(getAnchorTagLocatorByText(moduleName));

			// Get the list of sub-module elements
			List<WebElement> subModuleElements = commonEvents.getWebElements(getSubModuleLocator());
			System.out.println("Sub-module count: " + subModuleElements.size());

			// Check if the sub-modules are displayed
			if (!subModuleElements.isEmpty()) {
				for (WebElement subModule : subModuleElements) {
					boolean isDisplayed = commonEvents.isDisplayed(subModule);
					System.out.println("Sub-module displayed: " + isDisplayed);
					areModulesDisplayed = areModulesDisplayed || isDisplayed;
				}
			} else {
				System.out.println("No sub-modules found under the specified module.");
			}

		} catch (Exception e) {
			throw new Exception("Failed to find elements: " + e.getMessage(), e);
		}
		return areModulesDisplayed;
	}

	/**
	 * @Test6 about this method verifyNavigationBetweenSubmodules()
	 * 
	 * @param : null
	 * @description : This method verifies that the user is able to navigate between
	 *              the sub modules.
	 * @return : boolean
	 * @author : YAKSHA
	 */
	public boolean verifyNavigationBetweenSubmodules() throws Exception {
		try {
			// Clicking on the "Inventory" submodule to start navigation.
			commonEvents.click(getAnchorTagLocatorByText("Inventory"));

			// Navigating to the "Stock" submodule and waiting for the URL to update.
			commonEvents.click(getAnchorTagLocatorByText("Stock"));
			commonEvents.waitForUrlContains("Inventory/Stock", 5000);

			// Navigating to the "Inventory Requisition" submodule and waiting for the URL
			// to update.
			commonEvents.click(getAnchorTagLocatorByText("Inventory Requisition"));
			commonEvents.waitForUrlContains("Inventory/InventoryRequisitionList", 5000);

			// Navigating to the "Consumption" submodule and waiting for the URL to update.
			commonEvents.click(getAnchorTagLocatorByText("Consumption"));
			commonEvents.waitForUrlContains("Inventory/Consumption/ConsumptionList", 5000);

			// Navigating to the "Reports" submodule and waiting for the URL to update.
			commonEvents.click(getAnchorTagLocatorByText("Reports"));
			commonEvents.waitForUrlContains("Inventory/Reports", 5000);

			// Navigating to the "Patient Consumption" submodule and waiting for the URL to
			// update.
			commonEvents.click(getAnchorTagLocatorByText("Patient Consumption"));
			commonEvents.waitForUrlContains("Inventory/PatientConsumption/PatientConsumptionList", 5000);

			// Navigating to the "Return" submodule and waiting for the URL to update.
			commonEvents.click(getAnchorTagLocatorByText("Return"));
			commonEvents.waitForUrlContains("Inventory/Return", 5000);

			// Finally, navigating back to the "Stock" submodule.
			commonEvents.click(getAnchorTagLocatorByText("Stock"));

			// Return true if all navigations are successful.
			return true;
		} catch (Exception e) {
			// Throwing the exception if any issue occurs during navigation.
			throw e;
		}
	}

	/**
	 * @Test7 about this method takingScreenshotOfTheCurrentPage()
	 * @param : null
	 * @description : Taking screenshot of the current page.
	 * @return : Boolean
	 * @author : YAKSHA
	 */
	public Boolean takingScreenshotOfTheCurrentPage() throws Exception {
		boolean isDisplayed = false;
		try {
			commonEvents.takeScreenshot("SubStore");
			isDisplayed = true;

		} catch (Exception e) {
			throw e;
		}
		return isDisplayed;
	}

	/**
	 * @Test8 about this method
	 *        verifyIfInventoryReqInputFieldsDropdownsAndCheckboxesAreVisibleOrNot()
	 * 
	 * @param : null
	 * @description : This method verifies the visibility of various UI components
	 *              on the page, including buttons, input fields, dropdowns, and
	 *              checkboxes.
	 * @return : boolean - Returns true if all specified UI components are
	 *         displayed, otherwise false.
	 * @throws : Exception - if there is an issue finding any of the UI components.
	 * @author : YAKSHA
	 */
	public boolean verifyIfInventoryReqInputFieldsDropdownsAndCheckboxesAreVisibleOrNot() throws Exception {
		boolean areAllFieldsDisplayed = false;
		try {
			commonEvents.click(getAnchorTagLocatorByText("Inventory Requisition"));
			commonEvents.waitForUrlContains("Inventory/InventoryRequisitionList", 5000);

			WebElement firstButton = commonEvents.findElement(getButtonLocatorsBytext("First"));
			WebElement previousButton = commonEvents.findElement(getButtonLocatorsBytext("Previous"));
			WebElement nextButton = commonEvents.findElement(getButtonLocatorsBytext("Next"));
			WebElement lastButton = commonEvents.findElement(getButtonLocatorsBytext("Last"));
			WebElement okButton = commonEvents.findElement(getButtonLocatorsBytext("OK"));
			WebElement createReqButton = commonEvents.findElement(getCreateRequisitionButton());
			WebElement searchBarId = commonEvents.findElement(searchBarId());
			WebElement starIconLocator = commonEvents.findElement(getStarIconLocator());
			WebElement pendingRadiobtn = commonEvents.findElement(getRadioButtonLocator("Pending"));
			WebElement completeRadiobtn = commonEvents.findElement(getRadioButtonLocator("Complete"));
			WebElement cancelledRadiobtn = commonEvents.findElement(getRadioButtonLocator("Cancelled"));
			WebElement withdrawnRadiobtn = commonEvents.findElement(getRadioButtonLocator("Withdrawn"));
			WebElement allRadiobtn = commonEvents.findElement(getRadioButtonLocator("All"));

			List<WebElement> options = Arrays.asList(firstButton, previousButton, nextButton, lastButton, okButton,
					searchBarId, createReqButton, starIconLocator, pendingRadiobtn, completeRadiobtn, cancelledRadiobtn,
					withdrawnRadiobtn, allRadiobtn);

			for (int i = 0; i < options.size(); i++) {
				WebElement option = options.get(i);
				commonEvents.highlight(option);
				if (!option.isDisplayed()) {
					areAllFieldsDisplayed = false;
					throw new Exception("Visibility check failed for: " + option.getText());
				}
			}
			areAllFieldsDisplayed = true;
		} catch (Exception e) {
			// Throw an exception with a meaningful message if any UI component is not found
			throw new Exception("Failed to verify if all fields are displayed!", e);
		}
		// Return the result of the visibility check
		return areAllFieldsDisplayed;
	}

	/**
	 * @Test9 about this method verifyCreateRequisitionButton()
	 * 
	 * @param : null
	 * @description : This method verifies that the user is able to click the
	 *              Requisition Button.
	 * @return : String - The success message if the requisition is created
	 *         successfully.
	 * @author : YAKSHA
	 */
	public String verifyCreateRequisitionButton() throws Exception {
		String requisitionSuccessMessage = "";
		try {
			// Locate and click the "Create Requisition" button.
			WebElement createReqButton = commonEvents.findElement(getCreateRequisitionButton());
			commonEvents.highlight(createReqButton).click(createReqButton);

			// Wait for the URL to contain the expected path after clicking the button.
			commonEvents.waitForUrlContains("Inventory/InventoryRequisitionItem", 5000);

			// Locate and wait for the "Request" button to be visible.
			WebElement requestButton = commonEvents.findElement(getRequestButton());
			commonEvents.waitTillElementVisible(requestButton, 10000);

			// Fill in the target inventory field.
			commonEvents.click(getTargetInventory()).sendKeys(getTargetInventory(), "General-Inventory")
					.sendKeys(getTargetInventory(), Keys.TAB).sendKeys(getTargetInventory(), Keys.TAB);

			// Locate the item name field, highlight it, and enter the item name.
			WebElement itemName = driver.findElement(getItemName());
			commonEvents.highlight(itemName);
			commonEvents.sendKeys(itemName, "tissue").sendKeys(itemName, Keys.ENTER);

			// Locate the required quantity field, highlight it, and enter the quantity.
			WebElement requiredQuantity = driver.findElement(getRequiredQuantity());
			commonEvents.highlight(requiredQuantity);
			commonEvents.sendKeys(requiredQuantity, "5");

			// Click the "Request" button after highlighting it.
			commonEvents.highlight(requestButton).click(requestButton);

			// Verify the success message after creating the requisition.
			WebElement element = commonEvents
					.findElement(getPopUpMessageText("success", "Requisition is Generated and Saved"));
			requisitionSuccessMessage = element.getText();
			System.out.println("Actual Success Message: " + requisitionSuccessMessage);

			// Close the popup and the requisition modal.
			commonEvents.click(popupCloseButton());
			commonEvents.click(getCloseModalLocator());

		} catch (Exception e) {
			// Throw a meaningful exception with details on what failed.
			throw new Exception("Failed to create requisition: " + e.getMessage(), e);
		}
		return requisitionSuccessMessage;
	}

	/**
	 * @Test10.1 about this method applyDateFilter()
	 *
	 * @param : String, String
	 * @description : Applies the date filter with date range
	 * @return : void
	 * @throws : Exception - if there is an issue finding or filling the date fields
	 * @author : YAKSHA
	 */
	public boolean applyDateFilter(String fromDate, String toDate) throws Exception {
		try {
			System.out.println("apply filter start");
			String fromDay, fromMonth, fromYear, toDay, toMonth, toYear;
			fromDay = fromDate.split("-")[0];
			fromMonth = fromDate.split("-")[1];
			fromYear = fromDate.split("-")[2];
			toDay = toDate.split("-")[0];
			toMonth = toDate.split("-")[1];
			toYear = toDate.split("-")[2];
			WebElement fromDateDropdown = commonEvents.findElement(calendarFromDropdown());
			WebElement toDateDropdown = commonEvents.findElement(calendarToDropdown());
			commonEvents.highlight(fromDateDropdown).sendKeys(fromDateDropdown, fromDay)
					.sendKeys(fromDateDropdown, fromMonth).sendKeys(fromDateDropdown, fromYear);
			commonEvents.highlight(toDateDropdown).sendKeys(toDateDropdown, toDay).sendKeys(toDateDropdown, toMonth)
					.sendKeys(toDateDropdown, toYear);
			WebElement okButton = commonEvents.findElement(getButtonLocatorsBytext("OK"));
			commonEvents.click(okButton);
			System.out.println("apply filter end");
		} catch (Exception e) {
			throw e;
		}
		return true;
	}

	/**
	 * @Test10.2 about this method verifyRequisitionDatesAsPerTheDateRange()
	 *
	 * @param : String fromDate, String toDate
	 * @description : Verifies that all requisition dates fall within the specified
	 *              date range.
	 * @return : boolean - true if all dates are within the range, false otherwise.
	 * @throws : Exception - if there is an issue finding or parsing the date
	 *           fields.
	 * @author : YAKSHA
	 */
	public boolean verifyRequisitionDatesAsPerTheDateRange(String fromDate, String toDate) throws Exception {
		try {
			// Define the date formats for parsing and formatting.
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Get the list of requisition dates after applying the filter.
			List<WebElement> actualDatesAfterFilterApplied = commonEvents.getWebElements(getAllRequisitionDate());

			// Parse the input date range.
			LocalDate from = LocalDate.parse(fromDate, formatter);
			LocalDate to = LocalDate.parse(toDate, formatter);

			// Loop through each date element to verify it falls within the specified range.
			for (WebElement dateElement : actualDatesAfterFilterApplied) {
				String dateText = dateElement.getText();
				LocalDate date;
				LocalDate newDate;
				try {
					// Parse the date and reformat it for comparison.
					date = LocalDate.parse(dateText, inputFormatter);
					newDate = LocalDate.parse(date.format(formatter), formatter);
				} catch (Exception e) {
					// Log and throw an exception if date parsing fails.
					throw new Exception("Date parsing failed for: " + dateText + ". " + e.getMessage(), e);
				}

				// Check if the date is outside the specified range.
				if (newDate.isBefore(from) || newDate.isAfter(to)) {
					return false;
				}
			}
			return true;
		} catch (Exception e) {
			// Throw a meaningful exception with details on what failed.
			throw new Exception("Failed to verify requisition dates within the specified date range: " + e.getMessage(),
					e);
		}
	}

	/**
	 * @Test11.1 about this method VerifyDateRangeButton()
	 * 
	 * @param : null
	 * @description : This method verifies that the user is able to navigate between
	 *              range button
	 * @return : boolean
	 * @author : YAKSHA
	 */
	public boolean VerifyDateRangeButton() throws Exception {
		try {
			WebElement dateRangeButton = driver.findElement(getDateRangeButton());
			commonEvents.highlight(dateRangeButton).click(dateRangeButton);

			WebElement oneWeekButton = driver.findElement(getOneWeekButton());
			commonEvents.highlight(oneWeekButton);
			commonEvents.click(oneWeekButton);
			return true;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test12 about this method verifyFilterByStoreFunctionality()
	 * 
	 * @param : null
	 * @description : This method verifies that the user is able to filter by store
	 *              functionality. It selects "GENERAL-INVENTORY" from a dropdown
	 *              and checks that all elements in the "Requested To" column
	 *              contain "GENERAL-INVENTORY".
	 * @return : boolean - Returns true if the filter functionality works as
	 *         expected, otherwise returns false.
	 * @author : YAKSHA
	 */

	public boolean verifyFilterByStoreFunctionality() {
		boolean columnContainsExpectedData = false;
		try {
			// Locate the dropdown element
			WebElement dropdownElement = commonEvents.findElement(getGeneralInventory());

			// Initialize the Select class with the dropdown WebElement
			Select dropdown = new Select(dropdownElement);

			// Select "GENERAL-INVENTORY" from the dropdown by visible text
			dropdown.selectByVisibleText("GENERAL-INVENTORY");

			// Retrieve all elements from the "Requested To" column
			List<WebElement> allRequestedToElements = commonEvents.getWebElements(getRequestedToColumn());

			// Loop through each element, starting from the second element (index 1)
			for (int i = 1; i < allRequestedToElements.size(); i++) {
				String elementText = allRequestedToElements.get(i).getText();
				System.out.println("Requested to data >> " + elementText);

				// If any element does not contain "GENERAL-INVENTORY", return false
				if (!elementText.contains("GENERAL-INVENTORY")) {
					return false;
				}
			}

			// If all elements contain "GENERAL-INVENTORY", return true
			columnContainsExpectedData = true;

		} catch (Exception e) {
			// Log the error with a meaningful message and the exception's stack trace
			System.err.println("Error occurred while verifying filter by store functionality: " + e.getMessage());
			e.printStackTrace();
		}
		return columnContainsExpectedData;
	}

	/**
	 * @Test13 about this method verifyInventoryRequisitionRadioButtonSection()
	 * 
	 * @param : null
	 * @description : This method verifies that all radio buttons in the Inventory
	 *              Requisition section are clickable and visible. It ensures that
	 *              each radio button ("Pending", "Complete", "Cancelled",
	 *              "Withdrawn", "All") can be clicked and is displayed correctly.
	 * @return : boolean - Returns true if all radio buttons are clickable and
	 *         visible, otherwise returns false.
	 * @author : YAKSHA
	 * @throws Exception
	 */

	public boolean verifyInventoryRequisitionRadioButtonSection() throws Exception {
		boolean areAllRadiobuttonClickable = false;
		try {
			// Locate all radio buttons in the Inventory Requisition section
			WebElement pendingRadiobtn = commonEvents.findElement(getRadioButtonLocator("Pending"));
			WebElement completeRadiobtn = commonEvents.findElement(getRadioButtonLocator("Complete"));
			WebElement cancelledRadiobtn = commonEvents.findElement(getRadioButtonLocator("Cancelled"));
			WebElement withdrawnRadiobtn = commonEvents.findElement(getRadioButtonLocator("Withdrawn"));
			WebElement allRadiobtn = commonEvents.findElement(getRadioButtonLocator("All"));

			// Store all radio buttons in a list for easy iteration
			List<WebElement> options = Arrays.asList(pendingRadiobtn, completeRadiobtn, cancelledRadiobtn,
					withdrawnRadiobtn, allRadiobtn);

			// Iterate through each radio button to verify visibility and clickability
			for (WebElement option : options) {
				commonEvents.highlight(option).click(option);
				if (!option.isDisplayed()) {
					// If any radio button is not visible after clicking, throw an exception
					throw new Exception("Visibility and Clickable check failed for: " + option.getText());
				}
			}

			// Click the "Pending" radio button to ensure it's the default selection
			commonEvents.click(pendingRadiobtn);

			// If all radio buttons were successfully clicked and are visible, set the flag
			// to true
			areAllRadiobuttonClickable = true;

		} catch (Exception e) {
			// Log the error with a meaningful message and the exception's stack trace
			throw new Exception(
					"Error occurred while verifying Inventory Requisition Radio Button Section: " + e.getMessage());
		}
		return areAllRadiobuttonClickable;
	}

	/**
	 * @Test14 about this method verifyRecordsAreFilteredAccordingToSearchData()
	 * 
	 * @param : null
	 * @description : This method verifies that the records displayed on the page
	 *              are filtered according to the search keyword entered into the
	 *              search bar. Specifically, it checks that all records in the
	 *              "Status" column contain the keyword "pending" after the search.
	 * @return : boolean - Returns true if the records are filtered correctly,
	 *         otherwise returns false.
	 * @throws Exception
	 * @throws :         Exception if any error occurs during the verification
	 *                   process.
	 */
	public boolean verifyRecordsAreFilteredAccordingToSearchData() throws Exception {
		boolean areDataFilteredAccordingToTheSearchedKeyword = false;
		try {
			// Locate the search bar element on the page
			WebElement searchBar = commonEvents.findElement(searchBarId());

			// Highlight the search bar, click on it, and enter the keyword "pending"
			commonEvents.highlight(searchBar).click(searchBar).sendKeys(searchBar, "pending");

			// Retrieve all elements from the "Status" column
			List<WebElement> allStatusColumnElements = commonEvents.getWebElements(getStatusColumnLocator());

			// Loop through each element in the "Status" column, starting from the second
			// element (index 1)
			for (int i = 1; i < allStatusColumnElements.size(); i++) {
				String elementText = allStatusColumnElements.get(i).getText();
				System.out.println("Status Column data >> " + elementText);

				// If any element does not contain the keyword "pending", return false
				if (!elementText.toLowerCase().contains("pending")) {
					return false;
				}
			}

			// If all elements contain the keyword, set the flag to true
			areDataFilteredAccordingToTheSearchedKeyword = true;

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception(
					"Error occurred while verifying records are filtered according to search data: " + e.getMessage(),
					e);
		}

		// Return the result of the verification
		return areDataFilteredAccordingToTheSearchedKeyword;
	}

	/**
	 * @Test15 about this method verifyPrintModalIsOpenedIfUserSelectsViewButton()
	 * 
	 * @param : null
	 * @description : This method verifies that the print modal is opened when the
	 *              user selects the "View" button from the dropdown. It also
	 *              verifies that the modal can be closed successfully.
	 * @return : boolean - Returns true if the print modal is opened upon clicking
	 *         the "View" button, otherwise returns false.
	 * @throws : Exception if any error occurs during the verification process.
	 */
	public boolean verifyPrintModalIsOpenedIfUserSelectsViewButton() throws Exception {
		boolean isModalOpened = false;
		try {
			// Retrieve all "View" buttons and select the first one
			List<WebElement> viewButtons = commonEvents.getWebElements(getAnchorTagLocatorByText("View"));
			WebElement firstViewButton = viewButtons.get(0);

			// Highlight and click the first "View" button
			commonEvents.highlight(firstViewButton).click(firstViewButton);

			// Verify if the print modal is displayed
			if (commonEvents.isDisplayed(printModalLocator())) {
				isModalOpened = true;
			}

			// Close the print modal
			commonEvents.click(getCloseModalLocator());

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception(
					"Error occurred while verifying that the print modal is opened when the 'View' button is selected: "
							+ e.getMessage(),
					e);
		}

		// Return the result of the modal verification
		return isModalOpened;
	}

	/**
	 * @Test16 about this method verifyPendingRecordCanBeCopied()
	 * 
	 * @param : null
	 * @description : This method verifies that records with a status of "Pending"
	 *              can be copied in the Inventory Requisition section. It checks
	 *              that after selecting "Create Copy" from the dropdown, the copied
	 *              record retains the "Pending" status and that the user is
	 *              correctly navigated back to the Inventory Requisition page after
	 *              clicking the "Request" button.
	 * @return : boolean - Returns true if the record is copied successfully and the
	 *         user is navigated back to the Inventory Requisition page, otherwise
	 *         returns false.
	 * @throws : Exception if any error occurs during the verification process.
	 */
	public boolean verifyPendingRecordCanBeCopied() throws Exception {
		boolean isCopySuccessful = false;
		String requisitionSuccessMessage = "";
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			WebElement inventoryReqisitionTab = commonEvents
					.findElement(getAnchorTagLocatorByText("Inventory Requisition"));
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", inventoryReqisitionTab);
			jsExecutor.executeScript("window.scrollBy(0, -50)");

			commonEvents.click(getAnchorTagLocatorByText("Pharmacy"));
			commonEvents.click(getAnchorTagLocatorByText("Inventory"));
			commonEvents.click(getAnchorTagLocatorByText("Inventory Requisition"));

			// Locate the specific record with status "Pending" and click the "..." dropdown
			List<WebElement> ellipsisButton = commonEvents.getWebElements(getEllipsisButtonByStatus("pending"));
			System.out.println("Ellipsis Button length >> " + ellipsisButton.size());
			WebElement firstellipsisButton = ellipsisButton.get(0);
			commonEvents.highlight(firstellipsisButton).click(firstellipsisButton);

			// Select "Create Copy" from the dropdown options
			WebElement createCopyOption = commonEvents.findElement(getAnchorTagLocatorByText("Create copy"));
			commonEvents.highlight(createCopyOption).click(createCopyOption);

			// Wait for the URL to contain the expected path after clicking the button.
			commonEvents.waitForUrlContains("Inventory/InventoryRequisitionItem", 5000);

			// Locate and wait for the "Request" button to be visible.
			WebElement requestButton = commonEvents.findElement(getRequestButton());
			commonEvents.waitTillElementVisible(requestButton, 10000);

			// Fill in the target inventory field.
			commonEvents.click(getTargetInventory()).sendKeys(getTargetInventory(), "General-Inventory")
					.sendKeys(getTargetInventory(), Keys.TAB);

			commonEvents.click(getRequiredQuantity()).sendKeys(getRequiredQuantity(), "1");

			// Click the "Request" button after highlighting it.
			commonEvents.highlight(requestButton).click(requestButton);

			// Verify the success message after creating the requisition.
			WebElement element = commonEvents
					.findElement(getPopUpMessageText("success", "Requisition is Generated and Saved"));
			requisitionSuccessMessage = element.getText();
			System.out.println("Actual Success Message: " + requisitionSuccessMessage);

			// Close the popup and the requisition modal.
			commonEvents.click(popupCloseButton());
			commonEvents.click(getCloseModalLocator());

			// If all checks pass, set the flag to true
			isCopySuccessful = true;

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception(
					"Error occurred while verifying that a 'Pending' record can be copied in the Inventory Requisition section: "
							+ e.getMessage(),
					e);
		}

		// Return the result of the copy verification
		return isCopySuccessful;
	}

	/**
	 * @Test17.1 @Test18.1 about this method verifyInventoryModule()
	 *
	 * @param : null
	 * @description : This method Verifies that presence of "Receive items" button
	 *              on inventory module.
	 * @return : boolean
	 * @author : YAKSHA
	 */
	public String verifyInventoryModule() throws Exception {
		String requisitionSuccessMessage = "";
		try {

			WebElement directDsipatchButton = commonEvents.findElement(getDirectDispatchButton());
			commonEvents.highlight(directDsipatchButton).click(directDsipatchButton);

			commonEvents.waitTillElementVisible(getStoreName(), 10000);

			WebElement storeName = commonEvents.findElement(getStoreName());
			commonEvents.highlight(storeName).click(storeName);
			commonEvents.sendKeys(storeName, "Accounts").sendKeys(storeName, Keys.ENTER);

			WebElement internalItemName = commonEvents.findElement(getInternalItemNameButton());
			commonEvents.highlight(internalItemName).click(internalItemName);
			commonEvents.sendKeys(internalItemName, "Soap").sendKeys(internalItemName, Keys.ENTER);

			WebElement dispatchedQuantity = commonEvents.findElement(getDispatchedQuantityButton());
			commonEvents.highlight(dispatchedQuantity).click(dispatchedQuantity);
			commonEvents.sendKeys(dispatchedQuantity, "2").sendKeys(dispatchedQuantity, Keys.ENTER);

			WebElement remarksButton = commonEvents.findElement(getRemarksButton());
			commonEvents.highlight(remarksButton).click(remarksButton);
			commonEvents.sendKeys(remarksButton, "Remarks123 ").sendKeys(remarksButton, Keys.ENTER);

			WebElement dispatchButton = driver.findElement(getInternalDirectDispatchButton());
			commonEvents.highlight(dispatchButton).click(dispatchButton);

			// Verify the success message after creating the requisition.
			WebElement element = commonEvents
					.findElement(getPopUpMessageText("notice", "Requisition is Generated and Saved"));
			requisitionSuccessMessage = element.getText();
			System.out.println("Actual Success Message: " + requisitionSuccessMessage);

			// Close the requisition modal.
			commonEvents.click(getCloseModalLocator());

		} catch (Exception e) {
			throw e;
		}
		return requisitionSuccessMessage;
	}

	/**
	 * @Test17.3 @Test18.4 about this method verifyReceiveitemsButtonFunctionality()
	 * 
	 * @param : successMsg - The expected success message that should be displayed
	 *          after receiving items.
	 * @description : This method verifies the functionality of the "Receive Items"
	 *              button in the Inventory Requisition section. It ensures that
	 *              clicking the button processes the receipt of items and displays
	 *              the correct success message.
	 * @return : String - Returns the actual success message displayed after the
	 *         items are received.
	 * @throws : Exception if any error occurs during the verification process.
	 */
	public String verifyReceiveitemsButtonFunctionality(String successMsg) throws Exception {
		String itemReceivedSuccessMsg = "";
		try {
			// Navigate to the "Inventory" section
			commonEvents.click(getAnchorTagLocatorByText("Inventory"));

			// Navigate to the "Inventory Requisition" section
			commonEvents.click(getAnchorTagLocatorByText("Inventory Requisition"));

			// Locate the specific record with status "Complete" and click the "Receive
			// Items" button
			List<WebElement> receivedItemsButtons = commonEvents.getWebElements(getReceiveButtonByStatus("complete"));
			System.out.println("Receive Items Button count: " + receivedItemsButtons.size());

			// Highlight and click the first "Receive Items" button in the list
			WebElement firstReceivedItemsButton = receivedItemsButtons.get(0);
			commonEvents.highlight(firstReceivedItemsButton).click(firstReceivedItemsButton);

			// Click the "Receive" button to confirm receipt
			WebElement receiveButton = driver.findElement(getRecieveButton());
			commonEvents.highlight(receiveButton).click(receiveButton);

			// Verify the success message after receiving the items
			WebElement element = commonEvents.findElement(getPopUpMessageText("Success", successMsg));
			itemReceivedSuccessMsg = element.getText();
			System.out.println("Actual Success Message: " + itemReceivedSuccessMsg);

			// Close the success message popup
			commonEvents.click(popupCloseButton());

			// Navigate back to the Inventory Requisition list
			commonEvents.click(getBackToReqListButton());

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception(
					"Error occurred while verifying the 'Receive Items' button functionality: " + e.getMessage(), e);
		}

		// Return the actual success message displayed after receiving items
		return itemReceivedSuccessMsg;
	}

	/**
	 * @Test18.3 about this method getSubCategoryAvailabilityCount()
	 * 
	 * @param : null
	 * @description : This method retrieves the available quantity of a specific
	 *              sub-category (in this case, "soap") from the inventory and
	 *              converts it from a String to an int for further processing.
	 * @return : boolean - Returns true if the operation is successful.
	 * @throws : Exception if any error occurs during the process.
	 */
	private int beforeAvailableQuantityReceived;

	public boolean getSubCategoryAvailabilityCount() throws Exception {
		try {
			// Locate the element displaying the available quantity for "soap"
			WebElement availableQtyElement = commonEvents.findElement(getStockAvailableQuantity("soap"));

			// Get the text of the available quantity and convert it to an integer
			String availableQtyText = availableQtyElement.getText();
			beforeAvailableQuantityReceived = Integer.parseInt(availableQtyText);

			// Log the retrieved and converted values
			System.out.println("Available qty before received >> " + availableQtyText);
			System.out.println("Available qty converted to int >> " + beforeAvailableQuantityReceived);

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception("Error occurred while retrieving and converting the available quantity for 'soap': "
					+ e.getMessage(), e);
		}
		return true;
	}

	/**
	 * @Test18.5 about this method verifyAvailableQtyCountIsIncreasedInStocks()
	 * 
	 * @param : null
	 * @description : This method verifies that the available quantity of "soap" has
	 *              increased after performing a specific operation. It retrieves
	 *              the available quantity, compares it with a previously recorded
	 *              value, and returns true if the quantity has increased. Logs
	 *              details of the available quantity before and after the
	 *              operation.
	 * @return : boolean - Returns true if the available quantity increased after
	 *         the operation, otherwise returns false.
	 * @throws : Exception if an error occurs while retrieving, processing, or
	 *           comparing the available quantity.
	 */
	public boolean verifyAvailableQtyCountIsIncreasedInStocks() throws Exception {
		try {
			commonEvents.click(getAnchorTagLocatorByText("Stock"));

			// Locate the element displaying the available quantity for "soap"
			WebElement availableQtyElement = commonEvents.findElement(getStockAvailableQuantity("soap"));

			// Wait for the element to become visible
			commonEvents.waitTillElementVisible(availableQtyElement, 10000);

			// Get the text of the available quantity and convert it to an integer
			String availableQtyText = availableQtyElement.getText();
			int afterAvailableQuantityReceived = Integer.parseInt(availableQtyText);

			// Log the retrieved and converted values
			System.out.println("Available qty after operation >> " + availableQtyText);
			System.out.println("Available qty converted to int >> " + afterAvailableQuantityReceived);

			// Check if the available quantity has increased
			if (beforeAvailableQuantityReceived < afterAvailableQuantityReceived) {
				return true;
			} else {
				System.out.println("No increase in available quantity. Before: " + beforeAvailableQuantityReceived
						+ ", After: " + afterAvailableQuantityReceived);
			}

		} catch (Exception e) {
			// Throw a new exception with a meaningful message if an error occurs
			throw new Exception(
					"Error occurred while verifying the increase in available quantity for 'soap': " + e.getMessage(),
					e);
		}
		return false;
	}

	/**
	 * @Test19.2 about this method verifyConsumptionCreationModule()
	 * 
	 * @param successMsg : Expected success message to validate.
	 * @description : This method verifies the process of creating a new consumption
	 *              record in the Consumption module.
	 * @return : String - The actual success message displayed after the operation.
	 * @throws : Exception if any error occurs during the process.
	 * @author : YAKSHA
	 */
	public String verifyConsumptionCreationModule(String successMsg) throws Exception {
		String consumptionCompleteMsg = "";
		try {
			// Navigate to the Consumption section and initiate a new record
			commonEvents.click(getAnchorTagLocatorByText("Inventory"));
			commonEvents.click(getAnchorTagLocatorByText("Consumption"));
			commonEvents.click(getAnchorTagLocatorByText("New Consumption"));

			// Enter item details and save the record
			WebElement itemName = driver.findElement(getInternalItemNameButton());
			commonEvents.highlight(itemName).sendKeys(itemName, "tissue").sendKeys(itemName, Keys.ENTER);

			WebElement consumedQty = driver.findElement(getDispatchedQuantityButton());
			commonEvents.highlight(consumedQty).click(consumedQty).sendKeys(consumedQty, "1");

			WebElement saveButtonElement = commonEvents.findElement(getSaveButtonLocator());
			commonEvents.highlight(saveButtonElement).click(saveButtonElement);

			// Verify the success message
			WebElement element = commonEvents.findElement(getPopUpMessageText("Success", successMsg));
			consumptionCompleteMsg = element.getText();
			System.out.println("Actual Success Message: " + consumptionCompleteMsg);

			// Close the success message popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw new Exception("Error occurred while creating consumption record: " + e.getMessage(), e);
		}
		return consumptionCompleteMsg;
	}

	/**
	 * @Test20 about this method verifyReportModule()
	 *
	 * @param : null
	 * @description : This method verifies the functionality of the "Reports"
	 *              section within the "Inventory" module. It clicks on the
	 *              "Reports" section, applies a date filter, generates a report,
	 *              and checks if the report table is displayed with results.
	 * @return : boolean - true if the report table is displayed with results, false
	 *         otherwise.
	 * @throws : Exception - if there is an issue with any of the operations
	 *           performed.
	 * @author : YAKSHA
	 */
	public boolean verifyReportModule() throws Exception {
		try {
			// Click on the "Reports" section and wait for the URL to contain the "Reports"
			commonEvents.click(getAnchorTagLocatorByText("Reports"));
			commonEvents.waitForUrlContains("Inventory/Reports", 10000);

			// Click on the counter element to proceed with the report generation.
			WebElement counterElement = commonEvents.findElement(getCounterReportModuleButton());
			commonEvents.highlight(counterElement).click(counterElement);

			// Apply the date filter from "01-08-2024" to the current date.
			String fromDate = "01-08-2024";
			String fromDay, fromMonth, fromYear;
			fromDay = fromDate.split("-")[0];
			fromMonth = fromDate.split("-")[1];
			fromYear = fromDate.split("-")[2];

			WebElement fromDateDropdown = commonEvents.findElement(calendarFromDropdown());
			commonEvents.highlight(fromDateDropdown).sendKeys(fromDateDropdown, fromDay)
					.sendKeys(fromDateDropdown, fromMonth).sendKeys(fromDateDropdown, fromYear);
			Thread.sleep(3000); // Wait for the date filter to apply

			// Click on the "Show Report" button to generate the report.
			WebElement showReportButton = commonEvents.findElement(getButtonLocatorsBytext("Show Report"));
			commonEvents.highlight(showReportButton).click(showReportButton);

			// Verify if the report table is visible and contains results.
			List<WebElement> reportsTableLocator = commonEvents.getWebElements(getReportsTableLocator());
			commonEvents.waitTillElementVisible(reportsTableLocator.get(0), 30000);

			// Return true if the report table has results, otherwise return false.
			if (reportsTableLocator.size() > 0) {
				return true;
			} else {
				throw new Exception("No reports found in the report table.");
			}
		} catch (Exception e) {
			// Throw a meaningful exception indicating what failed.
			throw new Exception("Failed to verify the Reports module functionality: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test21 about this method verifyConsumptionModule()
	 *
	 * @param : null
	 * @description : This method Verify and creating the functionality of "Reports"
	 *              section of the "Inventory" module
	 * @return : boolean
	 * @author : YAKSHA
	 */
	public String verifyReturnModule(String successMsg) throws Exception {
		String returnMsg = "";
		try {
			commonEvents.click(getAnchorTagLocatorByText("Return"));

			WebElement returnButton = driver.findElement(getReturnItemsButton());
			commonEvents.highlight(returnButton).click(returnButton);

			WebElement dropdownElement = commonEvents.findElement(getSelectInventoryButton());
			Select inventoryDropdown = new Select(dropdownElement);
			inventoryDropdown.selectByVisibleText("GENERAL-INVENTORY");

			WebElement itemName = commonEvents.findElement(getItemName());
			commonEvents.highlight(itemName).click(itemName).sendKeys(itemName, "soap").sendKeys(itemName, Keys.TAB);

			Thread.sleep(2000);

			WebElement returnQty = driver.findElement(getReturnQtyButton());
			commonEvents.highlight(returnQty).click(returnQty).clear(returnQty).sendKeys(returnQty, "1");

			commonEvents.click(getButtonLocatorsBytext("Return"));

			// Verify the success message
			WebElement element = commonEvents.findElement(getPopUpMessageText("success", successMsg));
			returnMsg = element.getText();
			System.out.println("Actual Success Message: " + returnMsg);

			// Close the success message popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw e;
		}
		return returnMsg;
	}
}
